import React from "react";
import AutoSlider from "../../Component/AutoSlider";
import Singlebanner from "../../assets/Images/Autoslider/Singlebanner.png";
import OurPolicies from "../../Component/OurPolicies";
import Connections from "../../Component/Connections";
import TreatmentSpecialities from "../../Component/TreatmentSpecialities";
import ServicePartner from "../../Component/ServicePartner";
import Testimonial from "../../Component/Testimonial";
import { IoChatbubbleEllipsesOutline } from "react-icons/io5";
import AutoSlider1 from "../../Component/AutoSlider1";
import GetLink from "../../Component/GetLink";
import AllDiseases from "../../Component/AllDiseases";
import ScrollingTagline from "../../Component/ScrollingTagline";



const Home = () => {
  return (
    <div className=" mt-[155px]">
      <div className="grid grid-cols-12">
        <div className=" col-span-8">
          <AutoSlider />
        </div>

        <div className=" col-span-4">
          <img src={Singlebanner} alt="" />
          <img src={Singlebanner} alt="" className="mt-3" />
        </div>
      </div>
      <ScrollingTagline/>
      <div className="">
        <div className=" px-14 bg-[#eff6ff]">
          <Connections />
        </div>
        <TreatmentSpecialities />
      
        <div className=" grid grid-cols-12  bg-[#eff6ff] mt-2 py-12">
        <div className=" col-span-9">
          <AutoSlider1 />
        </div>
        <div className=" col-span-3 mt-2">
          <p className="text-blue-500 font-semibold">BE A PART OF LIVO AAROGYA AADHAR</p>
          <h4 className="text-[#4b3279]" style={{fontWeight:"bold",fontSize:"30px"}}>Free Access <br />Free Support</h4>
          <p style={{fontWeight:"bold"}} className="text-[#4b3279]">Aarogya Aadhar Providing  <br /> Integrated Healthcare <br /> Solution</p>
         </div>
      </div>
        <div className="bg-[#eff6ff] py-8 mt-2">
        <Testimonial/>
        </div>
        <AllDiseases/>
        <div className=" bg-[#eff6ff] py-2 mt-2">
          <p className=" text-center mb-4 text-4xl font-bold text-blue-500">
            Our Service Partner in India
          </p>
          <p className=" text-center text-blue-500 mb-4">
            <span className="hover:text-[#4b3279] font-semibold cursor-pointer">Hospitals</span> |{" "}
            <span className="hover:text-[#4b3279] font-semibold cursor-pointer">
              Dignostic Center
            </span>{" "}
            |{" "}
            <span className="hover:text-[#4b3279] font-semibold cursor-pointer">
              Pathology Labs
            </span>{" "}
            |{" "}
            <span className="hover:text-[#4b3279] font-semibold cursor-pointer">
              Insurance Companies
            </span>{" "}
            | <span className="hover:text-[#4b3279] font-semibold cursor-pointer">Corporate</span>
          </p>

          <ServicePartner />
        </div>
       
      </div>
      
<GetLink/>
      <OurPolicies />
     
    </div>
  );
};

export default Home;
