import React, { useRef } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Img2 from '../assets/Images/NewSilder/img2.jpg'
import Img3 from '../assets/Images/NewSilder/img3.jpg'


function AutoSlider() {

  const CustomNextArrow = (props) => {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#3b82f6", zIndex:"40", marginRight:"25px"}}
        onClick={onClick}
      />
    );
  };

  const CustomPrevArrow = (props) => {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#3b82f6",  zIndex:"40", marginLeft:"25px" }}
        onClick={onClick}
      />
    );
  };

  const settings = {
    // dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    nextArrow: <CustomNextArrow />,
    prevArrow: <CustomPrevArrow />,
  };
  return (
    <>

    <div className="slider-container">
      {/* <h2>Auto Play {"&"} Pause with buttons</h2> */}
      <Slider  {...settings}>
        {/* <div>
         <img src={Img1} alt="" className=" h-44"/>
        </div> */}
        <div>
         <img src={Img2} alt="" />
        </div>
         <div>
         <img src={Img3} alt="" />
        </div>
        {/* <div>
         <img src={Img4} alt="" />
        </div>
        <div>
         <img src={Img5} alt="" />
        </div>
        <div>
         <img src={Img6} alt="" />
        </div> */}
      </Slider>
     
         </div>
         {/* <p className=" text-center my-7 text-2xl" >Aarogya Aadhar: India’s Leading Online Pharmacy & Healthcare Platform</p> */}
         </>
  );
}
export default AutoSlider;
