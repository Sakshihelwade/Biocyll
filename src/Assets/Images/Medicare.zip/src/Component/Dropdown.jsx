// // import React, { useState } from 'react';

// // const Dropdown = ({ label, options,textcolor }) => {
// //   const [isOpen, setIsOpen] = useState(false);
// //   let timeoutId;

// //   const openDropdown = () => {
// //     clearTimeout(timeoutId);
// //     setIsOpen(true);
// //   };

// //   const closeDropdown = () => {
// //     clearTimeout(timeoutId); 
// //     timeoutId = setTimeout(() => {
// //       setIsOpen(false);
// //     }, 200); 
// //   };
// //   return (
// //     <div className="relative inline-block text-left">
// //       <button
// //         className={`inline-flex justify-center w-full h-8 border border-blue-700 shadow-lg rounded-md text-${textcolor}  px-2 py-1  text-sm font-medium`}
// //         onMouseEnter={openDropdown}
// //         onMouseLeave={closeDropdown}
// //       >
// //         {label}
// //         <svg
// //           className={`ml-2 -mr-1 h-5 w-5 ${isOpen ? 'transform rotate-180' : ''}`}
// //           xmlns="http://www.w3.org/2000/svg"
// //           viewBox="0 0 20 20"
// //           fill="currentColor"
// //           aria-hidden="true"
// //         >
// //           <path
// //             fillRule="evenodd"
// //             d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 011.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.23 8.29a.75.75 0 01.02-1.06z"
// //             clipRule="evenodd"
// //           />
// //         </svg>
// //       </button>
// //       {isOpen && (
// //         <div
// //           className="absolute z-10 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5"
// //           onMouseEnter={openDropdown}
// //           onMouseLeave={closeDropdown}
// //         >
// //           <div className="py-1" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
// //             {options.map((option, index) => (
// //               <a
// //                 key={index}
// //                 href="#"
// //                 className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
// //                 role="menuitem"
// //                 onClick={closeDropdown}
// //               >
// //                 {option}
// //               </a>
// //             ))}
// //           </div>
// //         </div>
// //       )}
// //     </div>
// //   );
// // };

// // export default Dropdown;

// import React, { useState } from 'react';

// const Dropdown = ({ label, options, textcolor }) => {
//   const [isOpen, setIsOpen] = useState(false);
//   let timeoutId;

//   const openDropdown = () => {
//     clearTimeout(timeoutId);
//     setIsOpen(true);
//   };

//   const closeDropdown = () => {
//     clearTimeout(timeoutId);
//     timeoutId = setTimeout(() => {
//       setIsOpen(false);
//     }, 200);
//   };

//   return (
//     <div className="relative inline-block text-left">
//       <button
//         className={`inline-flex justify-center w-full h-8shadow-lg text-[#2e1065] rounded-md  px-2 py-1 text-sm font-medium`}
//         onMouseEnter={openDropdown}
//         onMouseLeave={closeDropdown}
//       >
//         {label}
//         <svg
//           className={`ml-2 -mr-1 h-5 w-5 ${isOpen ? 'transform rotate-180' : ''}`}
//           xmlns="http://www.w3.org/2000/svg"
//           viewBox="0 0 20 20"
//           fill="currentColor"
//           aria-hidden="true"
//         >
//           <path
//             fillRule="evenodd"
//             d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 011.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.23 8.29a.75.75 0 01.02-1.06z"
//             clipRule="evenodd"
//           />
//         </svg>
//       </button>
//       {isOpen && (
//         <div
//           className="absolute z-10 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 max-h-[30rem] overflow-y-auto"
//           onMouseEnter={openDropdown}
//           onMouseLeave={closeDropdown}
//         >
//           <div className="py-1" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
//             {options.map((option, index) => (
//               <a
//                 key={index}
//                 href="#"
//                 className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                 role="menuitem"
//                 onClick={closeDropdown}
//               >
//                 {option}
//               </a>
//             ))}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Dropdown;


// import React, { useState } from 'react';

// const Dropdown = ({ label, options, textcolor }) => {
//   const [isOpen, setIsOpen] = useState(false);
//   let timeoutId;

//   const openDropdown = () => {
//     clearTimeout(timeoutId);
//     setIsOpen(true);
//   };

//   const closeDropdown = () => {
//     clearTimeout(timeoutId);
//     timeoutId = setTimeout(() => {
//       setIsOpen(false);
//     }, 200);
//   };

//   const splitOptions = (options, maxPerColumn) => {
//     const columns = [];
//     for (let i = 0; i < options.length; i += maxPerColumn) {
//       columns.push(options.slice(i, i + maxPerColumn));
//     }
//     return columns;
//   };

//   const maxPerColumn = 11;
//   const optionColumns = splitOptions(options, maxPerColumn);
//   const dropdownWidth = optionColumns.length * 200; // Adjust the width based on the number of columns

//   return (
//     <div className="relative inline-block text-left">
//       <button
//         className={`inline-flex justify-center w-full h-8 shadow-lg text-[#2e1065] rounded-md px-2 py-1 text-sm font-medium`}
//         onMouseEnter={openDropdown}
//         onMouseLeave={closeDropdown}
//       >
//         {label}
//         <svg
//           className={`ml-2 -mr-1 h-5 w-5 ${isOpen ? 'transform rotate-180' : ''}`}
//           xmlns="http://www.w3.org/2000/svg"
//           viewBox="0 0 20 20"
//           fill="currentColor"
//           aria-hidden="true"
//         >
//           <path
//             fillRule="evenodd"
//             d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 011.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.23 8.29a.75.75 0 01.02-1.06z"
//             clipRule="evenodd"
//           />
//         </svg>
//       </button>
//       {isOpen && (
//         <div
//           className="absolute z-10 mt-2 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 max-h-[30rem] overflow-y-auto"
//           onMouseEnter={openDropdown}
//           onMouseLeave={closeDropdown}
//           style={{ width: `${dropdownWidth}px` }} // Adjust the width dynamically
//         >
//           <div className="py-1 flex" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
//             {optionColumns.map((column, columnIndex) => (
//               <div key={columnIndex} className="flex-1">
//                 {column.map((option, index) => (
//                   <a
//                     key={index}
//                     href="#"
//                     className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                     role="menuitem"
//                     onClick={closeDropdown}
//                   >
//                     {option}
//                   </a>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Dropdown;


// import React, { useState, useRef, useEffect } from 'react';

// const Dropdown = ({ label, options, textcolor }) => {
//   const [isOpen, setIsOpen] = useState(false);
//   const [dropdownWidth, setDropdownWidth] = useState(0);
//   const [dropdownPosition, setDropdownPosition] = useState('left');
//   const dropdownRef = useRef(null);
//   let timeoutId;

//   const openDropdown = () => {
//     clearTimeout(timeoutId);
//     setIsOpen(true);
//   };

//   const closeDropdown = () => {
//     clearTimeout(timeoutId);
//     timeoutId = setTimeout(() => {
//       setIsOpen(false);
//     }, 200);
//   };

//   useEffect(() => {
//     const maxOptionWidth = options.reduce((maxWidth, option) => {
//       const width = option.length * 10; // Adjust the multiplier as needed
//       return Math.max(maxWidth, width);
//     }, 0);

//     const columns = Math.ceil(options.length / 11);
//     const calculatedWidth = Math.min(columns * maxOptionWidth + columns * 20, window.innerWidth);

//     setDropdownWidth(calculatedWidth);

//     const handleResize = () => {
//       if (dropdownRef.current) {
//         const { right } = dropdownRef.current.getBoundingClientRect();
//         if (right > window.innerWidth) {
//           setDropdownPosition('right');
//         } else {
//           setDropdownPosition('left');
//         }
//       }
//     };

//     window.addEventListener('resize', handleResize);
//     handleResize(); // Initial check

//     return () => window.removeEventListener('resize', handleResize);
//   }, [options]);

//   const splitOptions = (options, maxPerColumn) => {
//     const columns = [];
//     for (let i = 0; i < options.length; i += maxPerColumn) {
//       columns.push(options.slice(i, i + maxPerColumn));
//     }
//     return columns;
//   };

//   const maxPerColumn = 11;
//   const optionColumns = splitOptions(options, maxPerColumn);

//   return (
//     <div className="relative inline-block text-left">
//       <button
//         className={`inline-flex justify-center w-full h-8 shadow-lg text-[#2e1065] rounded-md px-2 py-1 text-sm font-medium`}
//         onMouseEnter={openDropdown}
//         onMouseLeave={closeDropdown}
//       >
//         {label}
//         <svg
//           className={`ml-2 -mr-1 h-5 w-5 ${isOpen ? 'transform rotate-180' : ''}`}
//           xmlns="http://www.w3.org/2000/svg"
//           viewBox="0 0 20 20"
//           fill="currentColor"
//           aria-hidden="true"
//         >
//           <path
//             fillRule="evenodd"
//             d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 011.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.23 8.29a.75.75 0 01.02-1.06z"
//             clipRule="evenodd"
//           />
//         </svg>
//       </button>
//       {isOpen && (
//         <div
//           ref={dropdownRef}
//           className={`absolute z-10 mt-2 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 max-h-[30rem] overflow-y-auto ${dropdownPosition === 'right' ? 'right-0' : 'left-0'}`}
//           onMouseEnter={openDropdown}
//           onMouseLeave={closeDropdown}
//           style={{ width: `${dropdownWidth}px` }}
//         >
//           <div className="py-1 flex" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
//             {optionColumns.map((column, columnIndex) => (
//               <div key={columnIndex} className="flex-1">
//                 {column.map((option, index) => (
//                   <a
//                     key={index}
//                     href="#"
//                     className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 whitespace-nowrap"
//                     role="menuitem"
//                     onClick={closeDropdown}
//                   >
//                     {option}
//                   </a>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Dropdown;


// import React, { useState, useRef, useEffect } from 'react';

// const Dropdown = ({ label, options, textcolor }) => {
//   const [isOpen, setIsOpen] = useState(false);
//   const [dropdownWidth, setDropdownWidth] = useState(0);
//   const [dropdownPosition, setDropdownPosition] = useState('left');
//   const dropdownRef = useRef(null);
//   let timeoutId;

//   const openDropdown = () => {
//     clearTimeout(timeoutId);
//     setIsOpen(true);
//   };

//   const closeDropdown = () => {
//     clearTimeout(timeoutId);
//     timeoutId = setTimeout(() => {
//       setIsOpen(false);
//     }, 200);
//   };

//   useEffect(() => {
//     const maxOptionWidth = options.reduce((maxWidth, option) => {
//       const width = option.length * 10; // Adjust the multiplier as needed
//       return Math.max(maxWidth, width);
//     }, 0);

//     const columns = Math.ceil(options.length / 11);
//     const calculatedWidth = Math.min(columns * maxOptionWidth + (columns - 1) * 20, window.innerWidth - 20); // Adjust for the gap between columns

//     setDropdownWidth(calculatedWidth);

//     const handleResize = () => {
//       if (dropdownRef.current) {
//         const { right, left } = dropdownRef.current.getBoundingClientRect();
//         if (right > window.innerWidth) {
//           setDropdownPosition('right');
//         } else if (left < 0) {
//           setDropdownPosition('left');
//         }
//       }
//     };

//     window.addEventListener('resize', handleResize);
//     handleResize(); // Initial check

//     return () => window.removeEventListener('resize', handleResize);
//   }, [options]);

//   const splitOptions = (options, maxPerColumn) => {
//     const columns = [];
//     for (let i = 0; i < options.length; i += maxPerColumn) {
//       columns.push(options.slice(i, i + maxPerColumn));
//     }
//     return columns;
//   };

//   const maxPerColumn = 11;
//   const optionColumns = splitOptions(options, maxPerColumn);

//   return (
//     <div className="relative inline-block text-left">
//       <button
//         className={`inline-flex justify-center w-full h-8 shadow-lg text-[#2e1065] rounded-md px-2 py-1 text-sm font-medium`}
//         onMouseEnter={openDropdown}
//         onMouseLeave={closeDropdown}
//       >
//         {label}
//         <svg
//           className={`ml-2 -mr-1 h-5 w-5 ${isOpen ? 'transform rotate-180' : ''}`}
//           xmlns="http://www.w3.org/2000/svg"
//           viewBox="0 0 20 20"
//           fill="currentColor"
//           aria-hidden="true"
//         >
//           <path
//             fillRule="evenodd"
//             d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 011.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.23 8.29a.75.75 0 01.02-1.06z"
//             clipRule="evenodd"
//           />
//         </svg>
//       </button>
//       {isOpen && (
//         <div
//           ref={dropdownRef}
//           className={`absolute z-10 mt-2 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 max-h-[30rem] overflow-y-auto ${dropdownPosition === 'right' ? 'right-0' : 'left-0'}`}
//           onMouseEnter={openDropdown}
//           onMouseLeave={closeDropdown}
//           style={{ width: `${dropdownWidth}px` }}
//         >
//           <div className="py-1 flex" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
//             {optionColumns.map((column, columnIndex) => (
//               <div key={columnIndex} className="flex-1">
//                 {columnIndex > 0 && (
//                   <div className="border-l border-gray-200 h-full mx-2"></div>
//                 )}
//                 {column.map((option, index) => (
//                   <a
//                     key={index}
//                     href="#"
//                     className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 whitespace-nowrap text-[12px]"
//                     role="menuitem"
//                     onClick={closeDropdown}
//                   >
//                     {option}
//                   </a>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Dropdown;

import React, { useState, useRef, useEffect } from 'react';

const Dropdown = ({ label, options, textcolor }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [dropdownWidth, setDropdownWidth] = useState(0);
  const [dropdownPosition, setDropdownPosition] = useState('left');
  const dropdownRef = useRef(null);
  let timeoutId;

  const openDropdown = () => {
    clearTimeout(timeoutId);
    setIsOpen(true);
  };

  const closeDropdown = () => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => {
      setIsOpen(false);
    }, 200);
  };

  useEffect(() => {
    const maxOptionWidth = options.reduce((maxWidth, option) => {
      const width = option.length * 9; // Adjust the multiplier as needed
      return Math.max(maxWidth, width);
    }, 0);

    const columns = Math.ceil(options.length / 11); // Adjust the number of options per column if necessary
    const calculatedWidth = Math.min(columns * maxOptionWidth + (columns - 1) * 20, window.innerWidth - 20); // Adjust for the gap between columns

    setDropdownWidth(calculatedWidth);

    const handleResize = () => {
      if (dropdownRef.current) {
        const { right, left } = dropdownRef.current.getBoundingClientRect();
        if (right > window.innerWidth) {
          setDropdownPosition('right');
        } else if (left < 0) {
          setDropdownPosition('left');
        }
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize(); // Initial check

    return () => window.removeEventListener('resize', handleResize);
  }, [options]);

  const splitOptions = (options, maxPerColumn) => {
    const columns = [];
    for (let i = 0; i < options.length; i += maxPerColumn) {
      columns.push(options.slice(i, i + maxPerColumn));
    }
    return columns;
  };

  const maxPerColumn = 11;
  const optionColumns = splitOptions(options, maxPerColumn);

  return (
    <div className="relative inline-block text-left">
      <button
        className={`inline-flex justify-center w-full h-8 text-[#2e1065] rounded-md px-2 py-1 text-sm font-medium`}
        onMouseEnter={openDropdown}
        onMouseLeave={closeDropdown}
      >
        {label}
        <svg
          className={`ml-2 -mr-1 h-5 w-5 ${isOpen ? 'transform rotate-180' : ''}`}
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
        >
          <path
            fillRule="evenodd"
            d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 011.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.23 8.29a.75.75 0 01.02-1.06z"
            clipRule="evenodd"
          />
        </svg>
      </button>
      {isOpen && (
        <div
          ref={dropdownRef}
          className={`absolute z-10 mt-2 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 ${dropdownPosition === 'right' ? 'right-0' : 'left-0'}`}
          onMouseEnter={openDropdown}
          onMouseLeave={closeDropdown}
          style={{ width: `${dropdownWidth}px` }}
        >
          <div className="py-1 flex flex-wrap" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
            {optionColumns.map((column, columnIndex) => (
              <div key={columnIndex} className="flex flex-col flex-1 min-w-0" style={{ width: `${dropdownWidth / optionColumns.length}px` }}>
                {columnIndex > 0 && (
                  <div className="absolute left-0 top-0 bottom-0 border-l border-gray-200 mx-2"></div>
                )}
                {column.map((option, index) => (
                  <a
                    key={index} 
                    href="#"
                    className="block px-4 py-1 mb-2 text-sm text-gray-700 hover:bg-gray-100 whitespace-nowrap text-[12px]"
                    role="menuitem"
                    onClick={closeDropdown}
                  >
                    {option}
                  </a>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Dropdown;


