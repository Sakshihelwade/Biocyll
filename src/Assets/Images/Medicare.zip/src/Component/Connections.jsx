import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

const Connections = () => {
  useEffect(() => {
    AOS.init({
      duration: 1000, // duration of the animations in milliseconds
      once: true, // whether animation should happen only once - while scrolling down
    });
  }, []);

  return (
    <div>
      <section className="flex flex-wrap justify-evenly mb-2 py-2">
        <div data-aos="fade-up">
          <h2 className="text-blue-600 text-center text-3xl font-bold ">5500+</h2>
          <p className="text-center text-[#4b3279] font-medium">HEALTHCARE SERVICE PROVIDERS</p>
        </div>
        <div data-aos="fade-up" data-aos-delay="100">
          <h2 className="text-blue-600 text-center text-3xl font-bold ">50000+</h2>
          <p className="text-center text-[#4b3279] font-medium">PATIENTS</p>
        </div>
        <div data-aos="fade-up" data-aos-delay="200">
          <h2 className="text-blue-600 text-center text-3xl font-bold ">18+</h2>
          <p className="text-center text-[#4b3279] font-medium">CITIES</p>
        </div>
        <div data-aos="fade-up" data-aos-delay="300">
          <h2 className="text-blue-600 text-center text-3xl font-bold ">33+</h2>
          <p className="text-center text-[#4b3279] font-medium">SPECIALITIES</p>
        </div>
        <div data-aos="fade-up" data-aos-delay="400">
          <h2 className="text-blue-600 text-center text-3xl font-bold ">50+</h2>
          <p className="text-center text-[#4b3279] font-medium">TEAM ACROSS IN INDIA</p>
        </div>
      </section>
    </div>
  );
};

export default Connections;
