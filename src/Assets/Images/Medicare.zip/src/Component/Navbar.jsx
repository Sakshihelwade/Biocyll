// import React, { useState } from 'react'
// import Medicare from "../assets/Images/medicareLogo.png"
// import { FaSearch } from "react-icons/fa";
// import { FaCartArrowDown } from "react-icons/fa";
// import { IoMenu } from "react-icons/io5";
// import { IoClose } from "react-icons/io5";
// import { FaArrowLeft } from "react-icons/fa";
// import { Link, useNavigate } from 'react-router-dom';

// const Navbar = () => {
// const [openMenu,setOpenMenu]=useState(false)
// const [searchMenu,setSearchMenu]=useState(false)
// const navigate=useNavigate()
//   return (
//     <>
//     <div className={` py-2 w-full fixed top-0 bg-white z-50  ${searchMenu?" hidden":""}`}style={{boxShadow:'rgba(17, 17, 26, 0.1) 0px 4px 16px, rgba(17, 17, 26, 0.1) 0px 8px 24px, rgba(17, 17, 26, 0.1) 0px 16px 56px'}}>
//     <div className='flex justify-evenly gap-3 lg:gap-10 px-5 md:7 lg:px-10 '>
//       <div className=' flex justify-center items-center object-contain'>
//         <img src={Medicare} alt="" className=' h-12 md:h-auto'/>
//       </div>

// {/* <div className=' flex  gap-4'> */}
//       <div className=' hidden border p-2 mt-2 rounded-full md:w-full md:flex items-center '>
//       <FaSearch className=' h-4 w-4 mr-2 flex justify-center items-center'/>
//       <input type="search" name="" id="" placeholder=' search for products...' className=' h-7 outline-none w-full' />
//       </div>
//       <div className=' flex justify-center items-center md:hidden' onClick={()=>setSearchMenu(true)}>
//       <FaSearch className=' h-6 w-6 mr-2 flex justify-center items-center'/>
//       </div>
//      <div className=' hidden md:flex justify-center items-center'>
//       <button className=' bg-blue-500 flex justify-center items-center rounded-md text-white px-1 h-10 w-[110px]'>Shop Now</button>
//       </div>
//       <div className=' flex gap-1 justify-center items-center'>
//       <FaCartArrowDown  className=' h-10 w-6'/>Cart
//       </div>
//       <div className=' hidden md:flex justify-center items-center'>
//       <button className=' bg-blue-500 px-5 text-white flex justify-center items-center rounded-md h-10 w-[150px]'>Login | Register</button>
//       </div>
//       <div className='flex md:hidden  justify-center items-center cursor-pointer 'onClick={()=>setOpenMenu(!openMenu)}>
//       <IoMenu  className=' h-8 w-10'/>
//       </div>
//       {/* </div> */}

//       </div>
//       <hr className=' flex md:hidden'/>
//       <div className=' mt-4'>
//    <ul className=' hidden md:flex justify-evenly gap-2 cursor-pointer'>
//    {/* <li>HEALTH RESOURCES CENTER</li>
//     */}
//     <li ><Link to={'/all_product'} className='nav-menu-li' >HEALTH RESOURCES CENTER</Link></li>
//   <select>
//     VITAMIN & NUTRITION
//     <option value="">VITAMIN & NUTRITION</option>
//     <option value="">AAAAAAAA</option>
//     <option value="">BBBBBBBB</option>
//     <option value="">CCCCCCCC</option>
//     </select>
//   <li>DIABETES</li>
//   <li>AYURVEDA PRODUCTS </li>
//   <li>HOMEOPATHY </li>
//   <li>FEATURED</li>
//   <li>HEALTHCARE DEVICES</li>
//   <li>PERSONAL CARE</li>
//   <li>HEALTH CONDITIONS</li>
// </ul>
// <div className=' flex justify-between px-2 md:hidden'>
// <div className='flex justify-center items-center'>
//       <button className=' bg-blue-500 flex justify-center items-center rounded-md text-white px-1 h-10 w-[110px]'>Shop Now</button>
//       </div>
//       <div className='flex justify-center items-center'>
//       <button className=' bg-blue-500 px-5 text-white flex justify-center items-center rounded-md h-10 w-[150px]'>Login | Register</button>
//       </div>
// </div>
//       </div>

//       <div className={`${openMenu?" block":" hidden"} bg-white md:hidden fixed top-14 h-[100vh] w-[100vw]`}>
//       {/* <div className=' flex justify-end mt-2 mr-2'>
//       <IoClose className=' h-7 w-7'/>
//       </div> */}
//      <ul className=' flex flex-col gap-2 justify-center items-center mt-10 cursor-pointer'>
//   <li><Link to={'./all_product'} >HEALTH RESOURCES CENTER</Link></li>

//   <li>VITAMIN & NUTRITION</li>
//   <li>DIABETES</li>
//   <li>AYURVEDA PRODUCTS </li>
//   <li>HOMEOPATHY </li>
//   <li>FEATURED</li>
//   <li>HEALTHCARE DEVICES</li>
//   <li>PERSONAL CARE</li>
//   <li>HEALTH CONDITIONS</li>
// </ul>
//       </div>
//       </div>

//       <div className={`${searchMenu?" border flex h-8 items-center mx-2 rounded-md mt-2 ":"hidden"}`}>
//       <FaArrowLeft className=' mr-3 cursor-pointer' onClick={()=>setSearchMenu(false)}/>
//         <input type="search" placeholder=' Search' className=' w-full outline-none'/>
//       </div>
//       </>
//   )
// }

// export default Navbar

import React, { useEffect, useState } from "react";
import Dropdown from "../Component/Dropdown";
import AppStore from "../assets/Images/App_Store.png";
import Aarogya_Aadhar_logo from "../assets/Images/Aarogya_Aadhar_logo.png";

const Navbar = () => {
  const dropdownData = [
    { label: "Expert Doctors", options: [
      "General Physician",
      "Chest Physician",
      "Pediatricians",
      "Obstetrician and Gynecologists",
      "IVF Consultant",
      "Otolaryngologists OR ENT",
      "Ophthalmologists / Eye Specialist",
      "Cardiologists",
      "Nephrologists",
      "General Surgeons",
      "Proctologist",
      "Orthopedics & Joint Replacement Surgeon",
      "Physiotherapist",
      "Oncologists / Cancer",
      "Radiologists",
      "Urologists",
      "Dermatologists",
      "Neurologists",
      "Psychiatrists",
      "Dentist",
      "Dietitian",
      "Sexologist",
      "Gastroenterologists",
      "Geriatric Medicine",
      "Allergists",
      "Endocrinologists",
      "Cardiac Surgeons",
      "Rheumatologists",
      "Pulmonologists",
      "Anesthesiologists",
      "Ayurvedic",
      "Homeopathy",
      "Chiropractor"
  ] },
    {
      label: "Surgery Packages",
      options: ["Surgery Packages", "Treatement Packages"],
    },
    {
      label: "Home Healthcare",
      options: [
        "ICU at Home",
        "General Nursing",
        "Neurological Care and Rehabilitation",
        "Cancer Care on Bed",
        "Transplant and Post-Op Care",
        "COPD Care",
        "Cardiac Care",
        "Palliative Care",
        "Orthopaedic Care",
        "Stroke Care",
        "Bed Sores Care",
      ],
    },
    {
      label: "Hospitals",
      options: [
        "Government Hospital",
        "Private Hospital",
        "MJPJAY Hospital",
        "ESIC Hospital",
        "CGHS Hospital",
        "Trauma Care Hospital",
        "Cardiac Care Hospital",
        "Mother & Child Hospital",
        "Speciality Hospital",
        "Multispeciality Hospital",
        "Super-Speciality Hospital",
        "Cancer Hospital",
        "Eye Hospital",
        "IVF Center",
        "Dental Clinic",
        "Small Clinics",
      ],
    },
    {
      label: "Diagnostic Centers",
      options: [
        "ECG",
        "X-Ray Center",
        "CT Scan Center",
        "MRI Center",
        "Sonography Center",
        "Mammography Center",
        "Dental X-Ray Center",
        "Pet Scan",
        "Fluoroscopy",
        "Interventional Radiology",
        "Nuclear Medicine",
      ],
    },
    {
      label: "Pathology",
      options: [
        "Lab Tests",
        "Wellness Packages",
        // "Corporate Packages",
        "NABL Lab",
        "Blood Bank",
      ],
    },
    {
      label: "Health Insurance",
      options: ["Cashless Service", "TPA Service", "Gov Health Insurance"],
    },
    {
      label: "Corporate Health",
      options: [
        "Orthopedic Equipment & Supplies",
        "Endoscopy & Laparoscopy Instruments",
        "Surgical Instuments & Accessories",
        "Infusion Syringes & Supplies",
        "Surgical & ICU Equipments",
        "Medical Laboratory Instruments",
        "Physiotherapy & Rehab Aids",
        "Diagnostic Medical Imaging Equipment",
        "Dentist Tools, Equipment & Supplies",
        "Face Mask & Medical PPE Kits",
        "Hospital and Medical Furniture",
        "Bandages & Dressing Disposables",
        "Surgical & Medical Consumables",
        "Eye Diagnosis & Surgery Instruments",
        "ENT Surgical Equipment & Supplies",
        "Urological & Obstetrics Instruments",
        "Wheel Chairs, Crutches and Walker",
        "Medical & Surgical Clothing",
      ],
    },
    { label: "Pharmacy", options: ["TATA 1mg", "Tie up Page"] },
  ];

  const TopDropdownData = [
    {
      label: "Registration",
      options: [
        "Registration for Patient",
        "Registration for Doctor",
        "Registration for Hospital / Clinic",
        "Registration for Pathology",
        "Registration for Diagnostic Center",
        "Registration for Ambulance",
        "Registration for Health Worker",
        "Registration for Corporate ",
        "Equipment Sellers",
      ],
    },
    {
      label: "Login",
      options: [
        "Patient",
        "Doctor",
        "Hospital / Clinic",
        "Pathology",
        "Diagnostic Center",
        "Ambulance",
        "Health Worker",
        "Corporate Company",
        "Equipment Sellers",
      ],
    },
    { label: "Language", options: ["English", "Mrathi", "Hindi"] },
    // {
    //   label: "Help ?",
    //   options: ["Service 1", "Service 2", "Service 3"],
    // },
  ];

  const [dateTime, setDateTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setDateTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className=" fixed top-0 w-full z-50">
      <div className="flex justify-end bg-white py-1 px-8 space-x-2">
        <div className="text-black">
          <p className=" font-semibold  text-[#2e1065]">
            {" "}
            <span className=" font-semibold text-[#2e1065]">
              Date & Time in India :{" "}
            </span>{" "}
            {dateTime.toLocaleDateString()} {dateTime.toLocaleTimeString()}
          </p>
        </div>
        {TopDropdownData.map((dropdown, index) => (
          <Dropdown
            key={index}
            label={dropdown.label}
            options={dropdown.options}
            textcolor={"text-[#2e1065]"}
          />
        ))}
        <button className=" text-sm font-medium  text-[#2e1065] pb-2">Help ?</button>
      </div>

      <div className=" absolute top-[4px] left-8 ">
        <img src={Aarogya_Aadhar_logo} alt="" className=" " />
      </div>

      <div className="flex w-full px-4 bg-white">
        <div className="flex flex-col flex-grow">
          <div className="grid grid-cols-2 gap-2 mb-2 ml-56">
            <input
              type="text"
              placeholder="Location"
              className="border border-blue-700 w-full outline-none rounded-md px-2 h-8"
            />
            <input
              type="text"
              placeholder="Search for healthcare services"
              className="w-full rounded-md border outline-none border-blue-700 px-2 h-8"
            />
          </div>
          <div className="flex gap-2">
  <button className="flex-grow inline-flex justify-center items-center h-8 border border-blue-700 shadow-lg rounded-md text-sm font-medium">
    <span className="animate-textPulse">Book Free Appointment</span>
  </button>
  <button className="flex-grow inline-flex justify-center items-center h-8 border border-blue-700 shadow-lg rounded-md text-sm font-medium">
    <span className="animate-textPulse">Book Ambulance</span>
  </button>
  <button className="flex-grow inline-flex justify-center items-center h-8 border border-blue-700 shadow-lg rounded-md text-sm font-medium">
    <span className="animate-textPulse">Bed Booking</span>
  </button>
  <button className="flex-grow inline-flex justify-center items-center h-8 border border-blue-700 shadow-lg rounded-md text-sm font-medium">
    <span className="animate-textPulse">Apply Health Card</span>
  </button>
  <button className="flex-grow inline-flex justify-center items-center h-8 border border-blue-700 shadow-lg rounded-md text-sm font-medium">
    <span className="animate-textPulse">Job Portal</span>
  </button>
</div>


        </div>
        <div className="flex justify-center items-center h-[70px] w-52 rounded-md border border-blue-500 ml-4">
          <h2 className="text-xl font-semibold text-[#2e1065]">AarogyaDhan</h2>
        </div>
      </div>

      {/* </div> */}
      <div className="flex justify-center bg-white shadow-lg pt-1 space-x-2">
        {dropdownData.map((dropdown, index) => (
          <Dropdown
            key={index}
            label={dropdown.label}
            options={dropdown.options}
          />
        ))}
      </div>
    </div>
  );
};

export default Navbar;
