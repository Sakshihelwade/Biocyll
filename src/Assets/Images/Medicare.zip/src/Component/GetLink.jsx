import React from "react";

const GetLink = () => {
  return (
    <>
      <div className="flex flex-wrap gap-4 items-center justify-center bg-[#eff6ff] py-4">
        <div className="">
          <h3 className="text-2xl font-semibold text-[#4b3279]">
            Get the link to download app
          </h3>
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            className="w-full h-10 py-1 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
            placeholder="Enter phone number"
            aria-label="Search"
          />
          <button
            className="bg-blue-900 flex justify-center items-center  h-10 w-32 text-white px-0 py-3 rounded-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500"
            type="button"
          >
            Send Link
          </button>
        </div>
      </div>
    </>
  );
};

export default GetLink;
