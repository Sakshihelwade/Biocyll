import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { BiSolidQuoteLeft } from "react-icons/bi";

function TestimonialData() {
  const Testimonialdata = [
    { Data: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Harum rem, consequatur soluta laudantium nisi consequuntur molestiae tempora nihil nemo, laborum aspernatur mollitia ad qui dignissimos illo? Eos, reiciendis eligendi." ,name:"- Vishal Patil , Nov 2024"},
    { Data: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Harum rem, consequatur soluta laudantium nisi consequuntur molestiae tempora nihil nemo, laborum aspernatur mollitia ad qui dignissimos illo? Eos, reiciendis eligendi." ,name:"- Vishal Patil , Nov 2024" },
    { Data: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Harum rem, consequatur soluta laudantium nisi consequuntur molestiae tempora nihil nemo, laborum aspernatur mollitia ad qui dignissimos illo? Eos, reiciendis eligendi." ,name:"- Vishal Patil , Nov 2024" },
    { Data: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Harum rem, consequatur soluta laudantium nisi consequuntur molestiae tempora nihil nemo, laborum aspernatur mollitia ad qui dignissimos illo? Eos, reiciendis eligendi." ,name:"- Vishal Patil , Nov 2024" },
    { Data: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Harum rem, consequatur soluta laudantium nisi consequuntur molestiae tempora nihil nemo, laborum aspernatur mollitia ad qui dignissimos illo? Eos, reiciendis eligendi." ,name:"- Vishal Patil , Nov 2024" },
  ];

  const CustomNextArrow = (props) => {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{
          ...style,
          display: "block",
          background: "#cbd5e1",
          zIndex: "40",
        }}
        onClick={onClick}
      />
    );
  };

  const CustomPrevArrow = (props) => {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{
          ...style,
          display: "block",
          background: "#cbd5e1",
          zIndex: "40",
        }}
        onClick={onClick}
      />
    );
  };

  var settings = {
    infinite: true,
    speed: 500,
    slidesToScroll: 1,
    slidesToShow: 3,
    autoplay: true,
    autoplaySpeed: 2000,
    nextArrow: <CustomNextArrow />,
    prevArrow: <CustomPrevArrow />,
  };

  return (
    <div className="slider-container bg-gray-50 px-10 py-6 mt-8">
      <Slider {...settings}>
        {Testimonialdata.map((item, i) => (
      <div className="px-2 ">

          <div
            key={i}
            className="bg-white shadow-md rounded-md p-4" // Apply horizontal margin for gap
          >
            <div className="">
              <p className="text-center flex mb-4 text-[#4b3279]"><BiSolidQuoteLeft className="h-6 w-24 text-blue-500 "/>{item.Data}</p>
              <p className=" flex justify-end pr-2 font-semibold text-[#4b3279]">{item.name}</p>
            </div>
          </div>
      </div>

        ))}
      </Slider>
    </div>
       
  );
}

export default TestimonialData;
