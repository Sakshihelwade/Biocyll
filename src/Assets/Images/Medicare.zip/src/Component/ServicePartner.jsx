import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Img10 from '../assets/Images/SevicePartner/img10.jpg'
import Img11 from '../assets/Images/SevicePartner/img11.jpg'
import Img12 from '../assets/Images/SevicePartner/img12.jpg'
import Img1 from '../assets/Images/Autoslider/img1.png'
import Img2 from '../assets/Images/Autoslider/img2.png'
import Img3 from '../assets/Images/Autoslider/img3.png'
import Img4 from '../assets/Images/Autoslider/img4.png'
import Img5 from '../assets/Images/Autoslider/img5.png'
import Img6 from '../assets/Images/Autoslider/img6.png'

function ServicePartner() {
 
  const ServicePartner=[
    {img:Img10,name:"Aarogya Aadhar"},
    {img:Img11,name:"Aarogya Aadhar"},
    {img:Img12,name:"Aarogya Aadhar"},
    {img:Img10,name:"Aarogya Aadhar"},
    {img:Img11,name:"Aarogya Aadhar"},
    {img:Img12,name:"Aarogya Aadhar"},
    {img:Img10,name:"Aarogya Aadhar"},
    {img:Img11,name:"Aarogya Aadhar"},
    {img:Img12,name:"Aarogya Aadhar"},
    // {img:Img1,name:"Aarogya Aadhar"},
    // {img:Img2,name:"Aarogya Aadhar"},
    // {img:Img3,name:"Aarogya Aadhar"},
    // {img:Img4,name:"Aarogya Aadhar"},
    // {img:Img5,name:"Aarogya Aadhar"},
    // {img:Img6,name:"Aarogya Aadhar"},



]

const CustomNextArrow = (props) => {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#3b82f6", zIndex:"40", marginRight:"15px"}}
        onClick={onClick}
      />
    );
  };

  const CustomPrevArrow = (props) => {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#3b82f6",  zIndex:"40", marginLeft:"15px" }}
        onClick={onClick}
      />
    );
  };

  var settings = {
    // dots: true,
    infinite: true,
    speed: 500,
    slidesToScroll: 1,
    slidesToShow: 6,
    autoplay: true,
    autoplaySpeed: 2000 ,
       nextArrow: <CustomNextArrow />,
    prevArrow: <CustomPrevArrow />,
  };

  return (
    <div className="slider-container px-3 py-6  bg-gray-100">
      <Slider {...settings}>
        {
            ServicePartner.map((item,i)=>(
                <div key={i} className=" hover:shadow-lg hover:border-gray-400 hover:border-opacity-50 hover:cursor-pointer px-2 rounded-lg transition duration-300">
                    <div className=" flex justify-center items-center">
                <img src={item.img} alt="" className=" h-[200px] rounded-md"/>
                </div>
                <p className=" text-center font-semibold font-serif mt-4 text-[#4b3279]  ">{item.name}</p>
               </div> 
            ))

        }
       
       
      </Slider>
    </div>
  );
}

export default ServicePartner;
