import React, { useState, useEffect } from 'react';

const EnquireButton = () => {
    const [showButton, setShowButton] = useState(false);
    const [showForm, setShowForm] = useState(false);

    const handleScroll = () => {
        const scrollTop = window.scrollY;
        const windowHeight = window.innerHeight;
        if (scrollTop > windowHeight) {
            setShowButton(true);
        } else {
            setShowButton(false);
        }
    };

    useEffect(() => {
        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const handleButtonClick = () => {
        setShowForm(true);
    };

    const handleCloseForm = () => {
        setShowForm(false);
    };

    return (
        <div>
            {showButton && (
             
               <button
                   onClick={handleButtonClick}
                   className="flex justify-center text-sm leading-5 items-center fixed top-44 right-5 h-24 w-24 bg-blue-500 text-white rounded-full p-4 shadow-lg hover:bg-blue-700 transition duration-300"
                   style={{ zIndex: 40 }}
               >
               
               Connect with  Aarogya Rakshak
               </button>
          
           
            )}

            {showForm && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center" style={{ zIndex: 1100 }}>
                    <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md mx-4">
                        <h2 className="text-2xl font-bold mb-4">Get Started</h2>
                        <form>
                            <div className="mb-2">
                                <label className="block text-gray-700">Full Name</label>
                                <input type="text" placeholder='Enter Full Name' className="w-full p-2 border border-gray-300 rounded-md" />
                            </div>
                            <div className="mb-2 flex space-x-3">
                                <div className="w-1/2">
                                    <label className="block text-gray-700">Age</label>
                                    <input type="number" placeholder='Enter Age' className="w-full p-2 border border-gray-300 rounded-md" />
                                </div>
                                <div className="w-1/2">
                                    <label className="block text-gray-700">Gender</label>
                                    <select className="w-full p-2 border border-gray-300 rounded-md" placeholder="Select Gender">
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                            </div>
                            <div className="mb-2 flex space-x-3">
                                <div className="w-1/2">
                                    <label className="block text-gray-700">Country</label>
                                    <input type="text" placeholder='Enter Country' className="w-full p-2 border border-gray-300 rounded-md" />
                                </div>
                                <div className="w-1/2">
                                    <label className="block text-gray-700">WhatsApp No</label>
                                    <input type="text" placeholder='Enter Whatsapp No' className="w-full p-2 border border-gray-300 rounded-md" />
                                </div>
                            </div>
                            <div className="mb-2">
                                <label className="block text-gray-700">Email ID</label>
                                <input type="email" placeholder="Enter Email ID" className="w-full p-2 border border-gray-300 rounded-md" />
                            </div>
                            <div className="mb-2">
                                <label className="block text-gray-700">Message</label>
                                <textarea className="w-full p-2 border border-gray-300 rounded-md" placeholder="Tell us more about your problem"></textarea>
                            </div>
                            <div className="flex justify-end">
                                <button type="button" onClick={handleCloseForm} className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700 transition duration-300 mr-2">Close</button>
                                <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-300">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default EnquireButton;
