import React, { useRef } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Img1 from '../assets/Images/Autoslider/img1.png'
import Img2 from '../assets/Images/Autoslider/img2.png'
import Img3 from '../assets/Images/Autoslider/img3.png'
import Img4 from '../assets/Images/Autoslider/img4.png'
import Img5 from '../assets/Images/Autoslider/img5.png'
import Img6 from '../assets/Images/Autoslider/img6.png'


function AutoSlider1() {


  const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000
  };
  return (
    <>

    <div className="slider-container">
      <Slider  {...settings}>
        <div>
         <img src={Img1} alt="" className=" h-44"/>
        </div>
        <div>
         <img src={Img2} alt="" />
        </div>
         <div>
         <img src={Img3} alt="" />
        </div>
        <div>
         <img src={Img4} alt="" />
        </div>
        <div>
         <img src={Img5} alt="" />
        </div>
        <div>
         <img src={Img6} alt="" />
        </div>
      </Slider>
     
         </div>
         </>
  );
}
export default AutoSlider1;
