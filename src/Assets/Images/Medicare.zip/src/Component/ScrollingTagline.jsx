import React from 'react';

const ScrollingTagline = () => {
  return (
    <div className="overflow-hidden whitespace-nowrap">
      <div className="inline-block animate-marquee font-medium text-[#4b3279]">
      Welcome to Aarogya Aadhar!!!    Welcome to Aarogya Aadhar!!!  Welcome to Aarogya Aadhar!!!   Welcome to Aarogya Aadhar!!!
      </div>
    </div>
  );
};

export default ScrollingTagline;