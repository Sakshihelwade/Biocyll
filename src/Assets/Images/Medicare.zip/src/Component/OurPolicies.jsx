import React from "react";
import Google_Play_Store from "../assets/Images/Google_Play_Store.png";
import App_Store from "../assets/Images/App_Store.png";
import { FaInstagramSquare } from "react-icons/fa";
import { FaFacebook } from "react-icons/fa";
import { FaTwitter } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa";
import { IoLogoYoutube } from "react-icons/io";
const OurPolicies = () => {
  return (
    <div className=" grid sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 py-2 pt-5 px-10 mt-2 bg-pink-50">
      <div>
        <h1 className=" text-lg font-bold pb-2">Know Us</h1>
        <p className=" cursor-pointer">About Us</p>
        <p className=" cursor-pointer py-2">Contact Us</p>
        <p className=" cursor-pointer">Press Coverage</p>
        <p className=" cursor-pointer py-2">Carrers</p>
        <p className=" cursor-pointer">Business Partnership </p>
        <p className=" cursor-pointer py-2">Become a Health Partner</p>
        <p className=" cursor-pointer">Corporate Governance</p>
      </div>
      <div>
        <h1 className=" text-lg font-bold pb-2">Our Policies</h1>
        <p className=" cursor-pointer">Privacy Policy</p>
        <p className=" cursor-pointer py-2">Terms and Conditions</p>
        <p className=" cursor-pointer">Editorial Policy</p>
        <p className=" cursor-pointer py-2">Return Policy</p>
        <p className=" cursor-pointer">IP Policy</p>
        <p className=" cursor-pointer py-2">Grievance Redressal Policy</p>
        <p className="cursor-pointer">Fake Jobs and Fraud Disclaimer</p>

      </div>
      <div>
        <h1 className=" text-lg font-bold pb-2">Our Services</h1>
        <p className="cursor-pointer">Features for Doctors</p>
          <p className="cursor-pointer py-2">Features for Hospitals</p>
          <p className="cursor-pointer">Features for HSP</p>
          <p className="cursor-pointer py-2">Features for Chemist</p>
          <p className="cursor-pointer">Features for Health Worker</p>
          <p className="cursor-pointer py-2">Features for Companies</p>
      </div>
      <div>
        <h1 className=" text-lg font-bold pb-2">Connect</h1>
        <p>Social Links</p>
        <div className=" flex gap-3 py-2">
          <FaFacebook className=" h-6 w-6 text-blue-700 cursor-pointer" />
          <FaInstagramSquare className=" h-6 w-6 text-red-500 cursor-pointer" />
          <FaTwitter className=" h-6 w-6 text-blue-700 cursor-pointer" />
          <IoLogoYoutube className=" h-6 w-6 text-red-500 cursor-pointer" />
          <FaLinkedin className=" h-6 w-6 text-blue-700 cursor-pointer" />
        </div>
        <p>Want daily dose of health?</p>
        <button className=" py-2">Sign Up</button>
      </div>

      <div>
        <h1 className=" text-lg font-bold pb-2">Download App</h1>
        <div className=" h-14 w-44 cursor-pointer">
          <img src={Google_Play_Store} alt="" />
        </div>
        <div className="h-14 w-44 cursor-pointer">
          <img src={App_Store} alt="" />
        </div>
      </div>
    </div>
  );
};

export default OurPolicies;
