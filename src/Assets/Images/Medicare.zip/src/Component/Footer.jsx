import React from "react";
import Reliable from "../assets/Images/footer-image/reliable-footer.png";
import Secure from "../assets/Images/footer-image/secure-footer.png";
import Affordable from "../assets/Images/footer-image/affordable-footer.png";

const Footer = () => {
  return (
    <div className=" bg-pink-50 pt-2 py-4 pb-8 md:px-20">
      <hr className="my-4 bg-slate-400" />
      <div className=" grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mx-10">
        <div className=" sm:flex gap-2">
          <div className=" flex items-center justify-center  ">
            <img src={Reliable} alt="" className=" sm:h-24 sm:w-72" />
          </div>
          <div>
            <h1 className=" text-3xl font-bold">Reliable</h1>
            <p className=" text-[15px]">
              All products displayed on Tata 1mg are procured from verified and
              licensed pharmacies. All labs listed on the platform are
              accredited
            </p>
          </div>
        </div>

        <div className=" sm:flex gap-2">
          <div className=" flex items-center justify-center">
            <img src={Secure} alt="" className=" sm:h-24 sm:w-72" />
          </div>
          <div>
            <h1 className=" text-3xl font-bold">Secure</h1>
            <p className=" text-[15px]">
              All products displayed on Tata 1mg are procured from verified and
              licensed pharmacies. All labs listed on the platform are
              accredited
            </p>
          </div>
        </div>

        <div className=" sm:flex gap-2">
          <div className=" flex items-center justify-center">
            <img src={Affordable} alt="" className=" sm:h-24 sm:w-72" />
          </div>
          <div>
            <h1 className=" text-3xl font-bold">Affordable</h1>
            <p className=" text-[15px]">
              All products displayed on Tata 1mg are procured from verified and
              licensed pharmacies. All labs listed on the platform are
              accredited
            </p>
          </div>
        </div>
      </div>
        </div>
  );
};

export default Footer;
