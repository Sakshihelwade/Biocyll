import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';

const AllDiseases = () => {
    return (
       <div className='  bg-[#eff6ff] mt-2 py-7'>   
        
        <h2 className=' text-4xl text-blue-500 text-center font-bold py-5 mb-4'>All Health Diseases</h2>
             <div className=' grid grid-cols-2 gap-3 px-60'>
            <div className=' flex gap-2'>
            <select name="" id="" className=' h-10 border text-[#4b3279] border-blue-500 w-full rounded-md outline-none'>
                <option value="" className='text-[#4b3279]'>Diseases-Index A</option>
                <option value="" className='text-[#4b3279]'>Diseases-Index A</option>
                <option value="" className="text-[#4b3279]">Diseases-Index A</option>
            </select>
            <button className=' h-10 bg-blue-900 text-white px-3 rounded-md'>Search</button>
            </div>
            <div>
                           <div className=' flex gap-2 '>
                <div className=' border flex  gap-2 h-10 bg-white rounded-md w-full border-blue-500'>
                <FontAwesomeIcon icon={faSearch} className="text-gray-400 pt-3 px-2" />
                <input type="text" placeholder=' Search Diseases' className=' outline-none w-full'/>

                </div>
            <button className=' h-10 bg-blue-900 text-white px-3 rounded-md'>Search</button>

                </div>
 
            </div>
        </div>
        </div>

    );
};

export default AllDiseases;
