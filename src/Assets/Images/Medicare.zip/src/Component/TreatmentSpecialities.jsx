// import React from 'react';
// import Img1 from '../assets/Images/TreatmentSpecialities/img1.png';
// import Img2 from '../assets/Images/TreatmentSpecialities/img2.png';
// import Img3 from '../assets/Images/TreatmentSpecialities/img3.png';
// import Img4 from '../assets/Images/TreatmentSpecialities/img4.png';
// import Img5 from '../assets/Images/TreatmentSpecialities/img5.png';
// import Img6 from '../assets/Images/TreatmentSpecialities/img6.png';
// import Img7 from '../assets/Images/TreatmentSpecialities/img7.png';
// import Img8 from '../assets/Images/TreatmentSpecialities/img8.png';
// import Img9 from '../assets/Images/TreatmentSpecialities/img9.png';
// import Img10 from '../assets/Images/TreatmentSpecialities/img10.png';
// import Img11 from '../assets/Images/TreatmentSpecialities/img11.png';
// import Img12 from '../assets/Images/TreatmentSpecialities/img12.png';
// import Img13 from '../assets/Images/TreatmentSpecialities/img13.png';
// import Img14 from '../assets/Images/TreatmentSpecialities/img14.png';
// import Img15 from '../assets/Images/TreatmentSpecialities/img15.png';
// import Img16 from '../assets/Images/TreatmentSpecialities/img16.png';
// import Img17 from '../assets/Images/TreatmentSpecialities/img17.png';
// import Img18 from '../assets/Images/TreatmentSpecialities/img18.png';
// import Img19 from '../assets/Images/TreatmentSpecialities/img19.png';
// import Img20 from '../assets/Images/TreatmentSpecialities/img20.png';
// import Img21 from '../assets/Images/TreatmentSpecialities/img21.png';

// const TreatmentSpecialities = () => {
//   const treatmentSpecialities = [
//     { img: Img1, name: "Brain" },
//     { img: Img2, name: "Eyes" },
//     { img: Img3, name: "Skin" },
//     { img: Img4, name: "ENT" },
//     { img: Img5, name: "Dental" },
//     { img: Img6, name: "Thyroid" },
//     { img: Img7, name: "Breast" },
//     { img: Img8, name: "Heart" },
//     { img: Img9, name: "Liver" },
//     { img: Img10, name: "Pancreas" },
//     { img: Img11, name: "Stomach" },
//     { img: Img12, name: "Gallbladder" },
//     // { img: Img13, name: "Kidney" },
//     // { img: Img14, name: "Spine" },
//     // { img: Img15, name: "Gynecology" },
//     // { img: Img16, name: "IVF" },
//     // { img: Img17, name: "Bone" },
//     // { img: Img18, name: "Pediatrics" },
//     // { img: Img19, name: "Cancer" },
//     // { img: Img20, name: "Male Reproductive System" },
//     // { img: Img21, name: "Joint Replacement" }
//   ];

//   const treatmentSpecialitiesAll=[
//     { img: Img1, name: "Brain" },
//     { img: Img2, name: "Eyes" },
//     { img: Img3, name: "Skin" },
//     { img: Img4, name: "ENT" },
//     { img: Img5, name: "Dental" },
//     { img: Img6, name: "Thyroid" },
//     { img: Img7, name: "Breast" },
//     { img: Img8, name: "Heart" },
//     { img: Img9, name: "Liver" },
//     { img: Img10, name: "Pancreas" },
//     { img: Img11, name: "Stomach" },
//     { img: Img12, name: "Gallbladder" },
//     { img: Img13, name: "Kidney" },
//     { img: Img14, name: "Spine" },
//     { img: Img15, name: "Gynecology" },
//     { img: Img16, name: "IVF" },
//     { img: Img17, name: "Bone" },
//     { img: Img18, name: "Pediatrics" },
//     { img: Img19, name: "Cancer" },
//     { img: Img20, name: "Male Reproductive System" },
//     { img: Img21, name: "Joint Replacement" }
//   ]

//   return (
//     <div>
//     <div className=" py-4 mt-4">
//       <h2 className="text-center mb-2 text-4xl font-bold text-blue-500">
//         Treatment by Specialities
//       </h2>
//       <p className="text-center mb-2 text-blue-500">Select the Speciality</p>
//       <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 mx-4 mt-2">
//         {treatmentSpecialities.map((item, i) => (
//           <div
//             key={i}
//             className="shadow-lg p-2 m-2 rounded-md bg-white flex flex-col items-center"
//           >
//             <div className="flex justify-center">
//               <img src={item.img} alt={item.name} className="img-fluid" />
//             </div>
//             <p className="text-center mt-3 text-primary font-bold">{item.name}</p>
//           </div>
//         ))}
//       </div>
//       <div className="flex justify-center mt-4">
//         <button className="bg-blue-500 text-white px-4 py-2 rounded-md shadow-md">
//           View More
//         </button>
//       </div>
//     </div>
//   </div>

//   );
// }

// export default TreatmentSpecialities;

import React, { useState } from "react";
import Img1 from "../assets/Images/TreatmentSpecialities/img1.png";
import Img2 from "../assets/Images/TreatmentSpecialities/img2.png";
import Img3 from "../assets/Images/TreatmentSpecialities/img3.png";
import Img4 from "../assets/Images/TreatmentSpecialities/img4.png";
import Img5 from "../assets/Images/TreatmentSpecialities/img5.png";
import Img6 from "../assets/Images/TreatmentSpecialities/img6.png";
import Img7 from "../assets/Images/TreatmentSpecialities/img7.png";
import Img8 from "../assets/Images/TreatmentSpecialities/img8.png";
import Img9 from "../assets/Images/TreatmentSpecialities/img9.png";
import Img10 from "../assets/Images/TreatmentSpecialities/img10.png";
import Img11 from "../assets/Images/TreatmentSpecialities/img11.png";
import Img12 from "../assets/Images/TreatmentSpecialities/img12.png";
import Img13 from "../assets/Images/TreatmentSpecialities/img13.png";
import Img14 from "../assets/Images/TreatmentSpecialities/img14.png";
import Img15 from "../assets/Images/TreatmentSpecialities/img15.png";
import Img16 from "../assets/Images/TreatmentSpecialities/img16.png";
import Img17 from "../assets/Images/TreatmentSpecialities/img17.png";
import Img18 from "../assets/Images/TreatmentSpecialities/img18.png";
import Img19 from "../assets/Images/TreatmentSpecialities/img19.png";
import Img20 from "../assets/Images/TreatmentSpecialities/img20.png";
import Img21 from "../assets/Images/TreatmentSpecialities/img21.png";

const TreatmentSpecialities = () => {
  const [showAllSpecialities, setShowAllSpecialities] = useState(false);

  const treatmentSpecialities = [
    { img: Img1, name: "Brain" },
    { img: Img2, name: "Eyes" },
    { img: Img3, name: "Skin" },
    { img: Img4, name: "ENT" },
    { img: Img5, name: "Dental" },
    { img: Img6, name: "Thyroid" },
    { img: Img7, name: "Breast" },
    { img: Img8, name: "Heart" },
    { img: Img9, name: "Liver" },
    { img: Img10, name: "Pancreas" },
    { img: Img11, name: "Stomach" },
    { img: Img12, name: "Gallbladder" },
    { img: Img13, name: "Kidney" },
    { img: Img14, name: "Spine" },
    { img: Img15, name: "Gynecology" },
    { img: Img16, name: "IVF" },
    { img: Img20, name: "Male Reproductive System" },
    { img: Img21, name: "Joint Replacement" },
    { img: Img17, name: "Bone" },
    { img: Img18, name: "Pediatrics" },
    { img: Img19, name: "Cancer" },
  ];

  const treatmentSpecialitiesAll = [
    { img: Img1, name: "Brain" },
    { img: Img2, name: "Eyes" },
    { img: Img3, name: "Skin" },
    { img: Img4, name: "ENT" },
    { img: Img5, name: "Dental" },
    { img: Img6, name: "Thyroid" },
    { img: Img7, name: "Breast" },
    { img: Img8, name: "Heart" },
    { img: Img9, name: "Liver" },
    { img: Img10, name: "Pancreas" },
    { img: Img11, name: "Stomach" },
    { img: Img12, name: "Gallbladder" },
    { img: Img13, name: "Kidney" },
    { img: Img14, name: "Spine" },
    { img: Img15, name: "Gynecology" },
    { img: Img16, name: "IVF" },
    { img: Img20, name: "Male Reproductive System" },
    { img: Img21, name: "Joint Replacement" },

    { img: Img17, name: "Bone" },
    { img: Img18, name: "Pediatrics" },
    { img: Img19, name: "Cancer" },
  ];

  const toggleSpecialities = () => {
    setShowAllSpecialities(!showAllSpecialities);
  };

  const specialitiesToDisplay = showAllSpecialities
    ? treatmentSpecialitiesAll
    : treatmentSpecialities;

  return (
    <div>
      <div className=" bg-[#eff6ff] py-[8px]">
        <h2 className="text-center mb-2 text-4xl font-bold text-blue-500">
          Treatment by Specialities
        </h2>
        <p className="text-center mb-2 text-blue-500">Select the Speciality</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 mx-4 mt-2">
          {specialitiesToDisplay.map((item, i) => (
            <div
              key={i}
              className=" p-2 m-2 rounded-md  flex flex-col items-center cursor-pointer" //shadow-lg bg-white
            >
              <div className="flex justify-center">
                <img src={item.img} alt={item.name} className="img-fluid" />
              </div>
              <p className="text-center mt-1 text-primary font-bold  text-[#4b3279]">
                {item.name}
              </p>
            </div>
          ))}
        </div>
        {/* <div className="flex justify-center mt-2">
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded-md shadow-md"
            onClick={toggleSpecialities}
          >
            {showAllSpecialities ? "View Less" : "View More"}
          </button>
        </div> */}
      </div>
    </div>
  );
};

export default TreatmentSpecialities;
