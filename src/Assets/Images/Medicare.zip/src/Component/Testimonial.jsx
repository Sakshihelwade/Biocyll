import React, { useState } from 'react'
import TestimonialData from './TestimonialData'

const Testimonial = () => {
const [testimonial,setTestimonial]=useState("Patients")

  return (
    <div className=' '>
      <h4 className=' text-center text-blue-500 font-bold text-4xl'>Testimonial</h4>
<div className='flex justify-center items-center gap-8 text-center mt-4'>
    <p className={`font-semibolds ${testimonial=="Patients"?"text-blue-500":"text-[#4b3279]"}`} style={{ cursor: "pointer",fontWeight:"initial" }} onClick={()=>setTestimonial("Patients")}><span style={{ textDecoration: testimonial === "Patients" ? "underline" : "none" }}>Patients</span> </p>
    <p className={` font-semibold ${testimonial=="Healthcare Service Providers"?"text-blue-500":"text-[#4b3279]"}`} style={{ cursor: "pointer",fontWeight:"initial" }} onClick={()=>setTestimonial("Healthcare Service Providers")}> <span style={{ textDecoration: testimonial === "Healthcare Service Providers" ? "underline" : "none" }}>Healthcare Service Providers</span> </p>
    <p className={` font-semibold ${testimonial=="Corporate"?"text-blue-500":"text-[#4b3279]"}`} style={{ cursor: "pointer",fontWeight:"initial" }} onClick={()=>setTestimonial("Corporate")}> <span style={{ textDecoration: testimonial === "Corporate" ? "underline" : "none" }}>Corporate</span> </p>
    <p className={` font-semibold ${testimonial=="Users"?"text-blue-500":"text-[#4b3279]"}`} style={{ cursor: "pointer",fontWeight:"initial" }} onClick={()=>setTestimonial("Users")}> <span style={{ textDecoration: testimonial === "Users" ? "underline" : "none" }}>Users</span> </p>
</div>


{testimonial === "Patients" ? (
    <>
    {/* <h3 className=' text-center'>Patients</h3> */}
  <TestimonialData />
  </>
) : testimonial === "Healthcare Service Providers" ? (
    <>
    {/* <h3 className=' text-center'>Healthcare Service Providers</h3> */}
    <TestimonialData />
    </>
) : testimonial === "Corporate" ? (
    <>
    {/* <h3 className=' text-center'>Companies</h3> */}
    <TestimonialData />
    </>
) : testimonial === "Users" ? (
    <>
    {/* <h3 className=' text-center'>Users</h3> */}
    <TestimonialData />
    </>
) : (
  ""
)}

    </div>
  )
}

export default Testimonial
