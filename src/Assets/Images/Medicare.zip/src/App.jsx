import { useState } from 'react'
import './App.css'
import Navbar from './Component/Navbar'
import Footer from './Component/Footer'
import All_Routes from './AllRoutes/All_Routes'
import EnquireButton from './Component/EnquireNow'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Navbar/>
      <All_Routes/>
     <EnquireButton/>
      <Footer/>
    </>
  )
}

export default App
